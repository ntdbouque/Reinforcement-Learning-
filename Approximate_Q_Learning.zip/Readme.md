# Pacman Reinforcement Learning Exercise

![img](assets/pacman.png)

This project is based on the UC Berkeley RL Exercise. This exercise includes, amongst other things, a Pacman game framework that is used in order to train RL agents to play the game (or a simplified version of it).